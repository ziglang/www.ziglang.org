<title id="title">Pagina Principale ⚡</title>
<head id="head">
  <link
  type="text/css"
  rel="stylesheet"
  href="/it-IT/css/home.css"
>
</head>
<div id="content" role="main">
  <div class="slogan alt-background">
    <div class="container slogan-message">
      <div
        style="max-width:790px;margin:10px 0;padding:0 5px"
        
      ><p>Zig e' un linguaggio di programmazione general purpose...</p>
      </div>
      <div class="cta-buttons">
        <a
          href="https://ziglang.org/learn/getting-started/"
          class="button main"
          style="margin-bottom:5px"
          
        >INIZIA</a>
        <span class="slogan-separator" style="font-size:.5em">
          Latest Release: &nbsp;
          <b>0.13.0</b>
        </span>
        <div style="display:flex;flex-direction:row;margin-top:5px">
          <a
            href="https://ziglang.org/documentation/0.13.0/"
            class="button"
            style="flex-grow:1;margin-top:0"
            
          >Documentazione</a>
          <a
            href="https://ziglang.org/download/0.13.0/release-notes.html"
            class="button"
            style="margin-left:5px;margin-top:0"
            
          >Changelog</a>
        </div>
      </div>
    </div>
  </div>
  <div class="container" style="display:flex;flex-direction:row;flex-wrap:wrap;padding:20px 0;justify-content:space-between">
    <div class="features">
      <div ><h2>⚡ Un linguaggio semplice</h2><h2>⚡ Comptime</h2><h2>⚡ Mantieni i tuoi progetti con Zig</h2></div>
      <div style="display:flex;flex-direction:row;flex-wrap:wrap;justify-content:center">
        <div>
          <h1>
            <a href="learn/overview/" class="button" style="display:inline">In-depth overview</a>
          </h1>
        </div>
        <div style="margin-left:5px">
          <h1>
            <a href="learn/samples/" class="button" style="display:inline">More code samples</a>
          </h1>
        </div>
      </div>
    </div>
    <div class="codesample" ><figure><figcaption class="zig-cap"><cite class="file">index.zig</cite></figcaption><pre><code><span class="tok-kw">const</span> std = <span class="tok-builtin">@import</span>(<span class="tok-str">&quot;std&quot;</span>);
<span class="tok-kw">const</span> parseInt = std.fmt.parseInt;

<span class="tok-kw">test</span> <span class="tok-str">&quot;parse integers&quot;</span> {
    <span class="tok-kw">const</span> input = <span class="tok-str">&quot;123 67 89,99&quot;</span>;
    <span class="tok-kw">const</span> ally = std.testing.allocator;

    <span class="tok-kw">var</span> list = std.ArrayList(<span class="tok-type">u32</span>).init(ally);
    <span class="tok-comment">// Ensure the list is freed at scope exit.</span>
    <span class="tok-comment">// Try commenting out this line!</span>
    <span class="tok-kw">defer</span> list.deinit();

    <span class="tok-kw">var</span> it = std.mem.tokenizeAny(<span class="tok-type">u8</span>, input, <span class="tok-str">&quot; ,&quot;</span>);
    <span class="tok-kw">while</span> (it.next()) |num| {
        <span class="tok-kw">const</span> n = <span class="tok-kw">try</span> parseInt(<span class="tok-type">u32</span>, num, <span class="tok-number">10</span>);
        <span class="tok-kw">try</span> list.append(n);
    }

    <span class="tok-kw">const</span> expected = [_]<span class="tok-type">u32</span>{ <span class="tok-number">123</span>, <span class="tok-number">67</span>, <span class="tok-number">89</span>, <span class="tok-number">99</span> };

    <span class="tok-kw">for</span> (expected, list.items) |exp, actual| {
        <span class="tok-kw">try</span> std.testing.expectEqual(exp, actual);
    }
}</code></pre></figure><figure><figcaption class="shell-cap">Shell</figcaption><pre><samp>$ <kbd>zig test index.zig</kbd>
1/1 index.test.parse integers...OK
All 1 tests passed.
</samp></pre></figure>
    </div>
  </div>
  <div class="alt-background">
    <div
      class="container"
      style="display:flex;flex-direction:column;justify-content:center;text-align:center;padding:20px 0"
      
    ><h1 id=community>Community</h1>
      <div class="container" style="display:flex;flex-direction:row;flex-wrap:wrap;justify-content:center">
        <div style="width:25%">
          <img
          src="/it-IT/ziggy.svg"
          style="max-height:200px"
        >
        </div>
        <div class="community-message">
          <div ><h1 id=decentralized>La community e' decentralizzata</h1></div>
          <div>
            <h1>
              <a
                href="https://github.com/ziglang/zig/wiki/Community"
                class="button"
                style="display:inline"
              >
                See all Communities
              </a>
            </h1>
          </div>
        </div>
      </div>
      <div style="height: 50px;"></div>
      <div class="container" style="display:flex;flex-direction:row;flex-wrap:wrap;justify-content:center">
        <div
          class="main-development-message"
          
        ><h2 id=main-development>Main development</h2></div>
        <div style="width:40%">
          <img src="/it-IT/zero.svg" style="max-height:200px">
        </div>
      </div>
    </div>
  </div>
  <div class="container" style="display:flex;flex-direction:column;justify-content:center;text-align:center;padding:20px 0">
    <div ><h2 id=zsf class="section-title ">Zig Software Foundation</h2><h2>The ZSF is a 501(c)(3) non-profit corporation.</h2></div>
    <h1>
      <a href="/it-IT/zsf/" class="button" style="display:inline">Learn More</a>
    </h1>
  </div>
  <div class="alt-background" style="padding:20px 0">
    <div class="container" ><h1 id=sponsors class="section-title ">Sponsors</h1>
      <div ><h2 id=corporate-sponsors>Corporate Sponsors</h2></div>
      <div class="monetary-logos">
        <a href="https://pex.com" rel="noopener nofollow" target="_blank">
          <picture>
            <source
            srcset="/it-IT/sponsors/pex-white.svg"
            media="(prefers-color-scheme: dark)"
          >
            <img src="/it-IT/sponsors/pex-dark.svg">
          </picture>
        </a>
        <a href="https://coil.com" rel="noopener nofollow" target="_blank">
          <picture>
            <source
            srcset="/it-IT/sponsors/coil-logo-white.svg"
            media="(prefers-color-scheme: dark)"
          ><img src="/it-IT/sponsors/coil-logo-black.svg">
          </picture>
        </a>
        <a href="https://tigerbeetle.com" rel="noopener nofollow" target="_blank" class="span2">
          <picture>
            <source
            srcset="/it-IT/sponsors/tb-logo-white.png"
            media="(prefers-color-scheme: dark)"
          ><img src="/it-IT/sponsors/tb-logo-black.png">
          </picture>
        </a>
        <a href="https://shiguredo.jp" rel="noopener nofollow" target="_blank">
          <picture>
            <source
            srcset="/it-IT/sponsors/shiguredo-logo-dark.svg"
            media="(prefers-color-scheme: dark)"
          ><img src="/it-IT/sponsors/shiguredo-logo-light.svg">
          </picture>
        </a>
        <a href="https://blacksmith.sh/?utm_source=ziglang&amp;utm_medium=banner&amp;utm_campaign=zig" rel="noopener nofollow" target="_blank">
          <picture>
            <source
            srcset="/it-IT/sponsors/Blacksmith_Logo-White.svg"
            media="(prefers-color-scheme: dark)"
          ><img src="/it-IT/sponsors/Blacksmith_Logo-Black.svg">
          </picture>
        </a>
      </div>
      <div ><h2 id=github-sponsors>GitHub Sponsors</h2></div>
      <div >