<!DOCTYPE html>
<html lang="en-US">
  <head id="head">
    <meta charset="utf-8">
    <title id="title">
      Home ⚡
      <span >Zig Programming Language</span>
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="color-scheme" content="light dark">
    <link rel="icon" href="/favicon.png">
    <link rel="icon" href="/favicon.svg">
    <link
    type="text/css"
    rel="stylesheet"
    href="/css/style.css"
  >
    <link
    type="text/css"
    rel="stylesheet"
    href="/css/navigation.css"
  >
    
  <link
  type="text/css"
  rel="stylesheet"
  href="/css/home.css"
>

  </head>
  <body>
    <div class="container">
      <a href="#"><span id="header-image"></span></a>
    </div>
    <nav id="mobile-navbar" class="nav container">
      <span style="overflow:hidden; max-width: 80%; display: inline-block; vertical-align:bottom;">
        {{ .Params.mobile_menu_title }}
      </span>
      <label for="mobile-toggle" id="hamburger">
        <svg style="width:2em;height:2em;" viewBox="0 0 24 24">
          <path fill="currentColor" d="M3,6H21V8H3V6M3,11H21V13H3V11M3,16H21V18H3V16Z"/>
        </svg>
      </label>
    </nav>
    <!--
		<div id="mobile-subnav">
		  <input type="checkbox" name="mobile-toggle" id="mobile-toggle">
		  <div class="" id="menu">
		    {{ with .Site.GetPage "download"}}
		      <a href="{{ "download/" | relLangURL }}" class="navbar-item">{{ .Params.mobile_menu_title }}</a>
		    {{ end }}
		    {{ with .Site.GetPage "learn"}}
		      <a href="{{ "learn/" | relLangURL }}" class="navbar-item">{{ .Params.mobile_menu_title }}</a>
		    {{ end }}
		    {{ with .Site.GetPage "news"}}
		      <a href="{{ "news/" | relLangURL }}" class="navbar-item">{{ .Params.mobile_menu_title }}</a>
		    {{ end }}
		    <a href="https://github.com/ziglang/zig" class="navbar-item external-link external-link-light">{{ i18n "menu-source" }}</a>
		    <a href="https://github.com/ziglang/zig/wiki/Community" class="navbar-item external-link external-link-light">{{ i18n "menu-community" }}</a>
		    {{ with .Site.GetPage "zsf"}}
		      <a href="{{ "zsf/" | relLangURL }}" class="navbar-item">
		        {{ .Params.mobile_menu_title }}</a>
		    {{ end }}
		  </div>
		</div>

		<nav id="navbar" class="nav">
		  <div class="container" style="display:flex; justify-content: space-between;">
		    <div>
		      {{ with .Site.GetPage "download"}}
		        <a href="{{ "download/" | relLangURL }}" class="navbar-item">{{ .Params.menu_title }}</a>
		      {{ end }} 
		      {{ with .Site.GetPage "learn"}}
		        <a href="{{ "learn/" | relLangURL }}" class="navbar-item">{{ .Params.menu_title }}</a>
		      {{ end }} 
		      {{ with .Site.GetPage "news"}}
		        <a href="{{ "news/" | relLangURL }}" class="navbar-item">{{ .Params.menu_title }}</a>
		      {{ end }} 
		      {{ with .Site.GetPage "zsf"}}
		        <a href="{{ "zsf/" | relLangURL }}" class="navbar-item" style="">
		          {{ .Params.menu_title }}
		        </a>
		      {{ end }}
		      <a href="https://github.com/ziglang/zig" class="navbar-item external-link external-link-light">{{ i18n "menu-source" }}</a> 
		      <a href="https://github.com/ziglang/zig/wiki/Community" class="navbar-item external-link external-link-light">{{ i18n "menu-community" }}</a> 
		    </div>
		  </div>
		</nav>
		-->
    <div id="content" role="main">
      
  <div class="slogan alt-background">
    <div class="container slogan-message">
      <div
        style="max-width:790px;margin:10px 0;padding:0 5px"
        
      ><p>Zig is a general-purpose programming language and toolchain for maintaining <strong>robust</strong>, <strong>optimal</strong> and <strong>reusable</strong> software.</p>
      </div>
      <div class="cta-buttons">
        <a
          href="https://ziglang.org/learn/getting-started/"
          class="button main"
          style="margin-bottom:5px"
          
        >GET STARTED