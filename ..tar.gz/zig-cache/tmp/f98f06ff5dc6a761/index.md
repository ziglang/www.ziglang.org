<!DOCTYPE html>
<html lang="en-US">
  <head id="head">
    <meta charset="utf-8">
    <title id="title">
      Home ⚡
      <span >Zig Programming Language</span>
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="color-scheme" content="light dark">
    <link rel="icon" href="/favicon.png">
    <link rel="icon" href="/favicon.svg">
    <link
    type="text/css"
    rel="stylesheet"
    href="/css/style.css"
  >
    <link
    type="text/css"
    rel="stylesheet"
    href="/css/navigation.css"
  >
    
  <link
  type="text/css"
  rel="stylesheet"
  href="/css/home.css"
>

  </head>
  <body>
    <div class="container">
      <a href="/"><span id="header-image"></span></a>
    </div>
    <nav id="mobile-navbar" class="nav container">
      <span
        style="overflow:hidden; max-width: 80%; display: inline-block; vertical-align:bottom;"
        
      >Home
      </span>
      <label for="mobile-toggle" id="hamburger">
        <svg style="width:2em;height:2em;" viewBox="0 0 24 24">
          <path fill="currentColor" d="M3,6H21V8H3V6M3,11H21V13H3V11M3,16H21V18H3V16Z"/>
        </svg>
      </label>
    </nav>
    <div id="mobile-subnav">
      <input type="checkbox" name="mobile-toggle" id="mobile-toggle">
      <div class="" id="menu">
        <div >
          <a
            class="navbar-item"
            href="/download/"
            
          >Download</a>
        </div>
        <div >
          <a
            class="navbar-item"
            href="/learn/"
            
          >Learn</a>
        </div>
        <div >
          <a class="navbar-item" href="/news/" >News</a>
        </div>
        <a
          href="https://github.com/ziglang/zig"
          class="navbar-item external-link external-link-light"
          
        >Source</a>
        <a
          href="https://github.com/ziglang/zig/wiki/Community"
          class="navbar-item external-link external-link-light"
          
        >Join a Community</a>
        <div >
          <a
            class="navbar-item"
            href="/zsf/"
            
          >ZSF</a>
        </div>
      </div>
    </div>
    <nav id="navbar" class="nav">
      <div class="container" style="display:flex; justify-content: space-between;">
        <div>
          <span >
            <a class="navbar-item" href="/download/" >Download</a>
          </span>
          <span >
            <a class="navbar-item" href="/learn/" >Learn</a>
          </span>
          <span >
            <a class="navbar-item" href="/news/" >News</a>
          </span>
          <span >
            <a class="navbar-item" href="/zsf/" >ZSF</a>
          </span>
          <a
            href="https://github.com/ziglang/zig"
            class="navbar-item external-link external-link-light"
            
          >Source</a>
          <a
            href="https://github.com/ziglang/zig/wiki/Community"
            class="navbar-item external-link external-link-light"
            
          >Join a Community</a>
        </div>
      </div>
    </nav>
    <div id="content" role="main">
      
  <div class="slogan alt-background">
    <div class="container slogan-message">
      <div
        style="max-width:790px;margin:10px 0;padding:0 5px"
        
      ><p>Zig is a general-purpose programming language and toolchain for maintaining <strong>robust</strong>, <strong>optimal</strong> and <strong>reusable</strong> software.</p>
      </div>
      <div class="cta-buttons">
        <a
          href="https://ziglang.org/learn/getting-started/"
          class="button main"
          style="margin-bottom:5px"
          
        >GET STARTED</a>
        <span class="slogan-separator" style="font-size:.5em">
          Latest Release: &nbsp;
          <b>0.13.0</b>
        </span>
        <div style="display:flex;flex-direction:row;margin-top:5px">
          <a
            href="https://ziglang.org/documentation/0.13.0/"
            class="button"
            style="flex-grow:1;margin-top:0"
            
          >Documentation</a>
          <a
            href="https://ziglang.org/download/0.13.0/release-notes.html"
            class="button"
            style="margin-left:5px;margin-top:0"
            
          >Changes</a>
        </div>
      </div>
    </div>
  </div>
  <div class="container" style="display:flex;flex-direction:row;flex-wrap:wrap;padding:20px 0;justify-content:space-between">
    <div class="features">
      <div ><h2>⚡ A Simple Language</h2><p>Focus on debugging your application rather than debugging your programming language knowledge.</p><ul><li>No hidden control flow.</li><li>No hidden memory allocations.</li><li>No preprocessor, no macros.</li></ul><h2>⚡ Comptime</h2><p>A fresh approach to metaprogramming based on compile-time code execution and lazy evaluation.</p><ul><li>Call any function at compile-time.</li><li>Manipulate types as values without runtime overhead.</li><li>Comptime emulates the target architecture.</li></ul><h2>⚡ Maintain it with Zig</h2><p>Incrementally improve your C/C++/Zig codebase.</p><ul><li>Use Zig as a zero-dependency, drop-in C/C++ compiler that supports cross-compilation out-of-the-box.</li><li>Leverage <code>zig build</code> to create a consistent development environment across all platforms.</li><li>Add a Zig compilation unit to C/C++ projects, exposing the rich standard library to your C/C++ code.</li></ul></div>
      <div style="display:flex;flex-direction:row;flex-wrap:wrap;justify-content:center">
        <div>
          <h1>
            <a href="learn/overview/" class="button" style="display:inline">In-depth overview</a>
          </h1>
        </div>
        <div style="margin-left:5px">
          <h1>
            <a href="learn/samples/" class="button" style="display:inline">More code samples</a>
          </h1>
        </div>
      </div>
    </div>
    <div class="codesample" ><figure><figcaption class="zig-cap"><cite class="file">index.zig</cite></figcaption><pre><code><span class="tok-kw">const</span> std = <span class="tok-builtin">@import</span>(<span class="tok-str">&quot;std&quot;</span>);
<span class="tok-kw">const</span> parseInt = std.fmt.parseInt;

<span class="tok-kw">test</span> <span class="tok-str">&quot;parse integers&quot;</span> {
    <span class="tok-kw">const</span> input = <span class="tok-str">&quot;123 67 89,99&quot;</span>;
    <span class="tok-kw">const</span> ally = std.testing.allocator;

    <span class="tok-kw">var</span> list = std.ArrayList(<span class="tok-type">u32</span>).init(ally);
    <span class="tok-comment">// Ensure the list is freed at scope exit.</span>
    <span class="tok-comment">// Try commenting out this line!</span>
    <span class="tok-kw">defer</span> list.deinit();

    <span class="tok-kw">var</span> it = std.mem.tokenizeAny(<span class="tok-type">u8</span>, input, <span class="tok-str">&quot; ,&quot;</span>);
    <span class="tok-kw">while</span> (it.next()) |num| {
        <span class="tok-kw">const</span> n = <span class="tok-kw">try</span> parseInt(<span class="tok-type">u32</span>, num, <span class="tok-number">10</span>);
        <span class="tok-kw">try</span> list.append(n);
    }

    <span class="tok-kw">const</span> expected = [_]<span class="tok-type">u32</span>{ <span class="tok-number">123</span>, <span class="tok-number">67</span>, <span class="tok-number">89</span>, <span class="tok-number">99</span> };

    <span class="tok-kw">for</span> (expected, list.items) |exp, actual| {
        <span class="tok-kw">try</span> std.testing.expectEqual(exp, actual);
    }
}</code></pre></figure><figure><figcaption class="shell-cap">Shell</figcaption><pre><samp>$ <kbd>zig test index.zig</kbd>
1/1 index.test.parse integers...OK
All 1 tests passed.
</samp></pre></figure>
    </div>
  </div>
  <div class="alt-background">
    <div
      class="container"
      style="display:flex;flex-direction:column;justify-content:center;text-align:center;padding:20px 0"
      
    ><h1 id=community class="section-title ">Community</h1>
      <div class="container" style="display:flex;flex-direction:row;flex-wrap:wrap;justify-content:center">
        <div style="width:25%">
          <img
          src="/ziggy.svg"
          style="max-height:200px"
        >
        </div>
        <div class="community-message">
          <div ><h2 id=decentralized>The Zig community is decentralized</h2><p>Anyone is free to start and maintain their own space for the community to gather.<br>There is no concept of "official" or "unofficial", however, each gathering place has its own moderators and rules.</p></div>
          <div>
            <h1>
              <a
                href="https://github.com/ziglang/zig/wiki/Community"
                class="button"
                style="display:inline"
              >
                See all Communities
              </a>
            </h1>
          </div>
        </div>
      </div>
      <div style="height: 50px;"></div>
      <div class="container" style="display:flex;flex-direction:row;flex-wrap:wrap;justify-content:center">
        <div
          class="main-development-message"
          
        ><h2 id=main-development>Main development</h2><p>The Zig repository can be found at <a href="https://github.com/ziglang/zig">https://github.com/ziglang/zig</a>, where we also host the issue tracker and discuss proposals.<br>Contributors are expected to follow Zig's <a href="https://github.com/ziglang/zig/blob/master/.github/CODE_OF_CONDUCT.md">Code of Conduct</a>.</p></div>
        <div style="width:40%">
          <img src="/zero.svg" style="max-height:200px">
        </div>
      </div>
    </div>
  </div>
  <div class="container" style="display:flex;flex-direction:column;justify-content:center;text-align:center;padding:20px 0">
    <div ><h1 id=zsf class="section-title ">Zig Software Foundation</h1><h2>The ZSF is a 501(c)(3) non-profit corporation.</h2><p>The Zig Software Foundation is a non-profit corporation founded in 2020 by Andrew Kelley, the creator of Zig, with the goal of supporting the development of the language. Currently, the ZSF is able to offer paid work at competitive rates to a small number of core contributors. We hope to be able to extend this offer to more core contributors in the future.</p><p>The Zig Software Foundation is sustained by donations.</p></div>
    <h1>
      <a href="/zsf/" class="button" style="display:inline">Learn More</a>
    </h1>
  </div>
  <div class="alt-background" style="padding:20px 0">
    <div class="container" ><h1 id=sponsors class="section-title ">Sponsors</h1>
      <div ><h2 id=corporate-sponsors>Corporate Sponsors</h2><p>The following companies are providing direct financial support to the Zig Software foundation.</p></div>
      <div class="monetary-logos">
        <a href="https://pex.com" rel="noopener nofollow" target="_blank">
          <picture>
            <source
            srcset="/sponsors/pex-white.svg"
            media="(prefers-color-scheme: dark)"
          >
            <img src="/sponsors/pex-dark.svg">
          </picture>
        </a>
        <a href="https://coil.com" rel="noopener nofollow" target="_blank">
          <picture>
            <source
            srcset="/sponsors/coil-logo-white.svg"
            media="(prefers-color-scheme: dark)"
          ><img src="/sponsors/coil-logo-black.svg">
          </picture>
        </a>
        <a href="https://tigerbeetle.com" rel="noopener nofollow" target="_blank" class="span2">
          <picture>
            <source
            srcset="/sponsors/tb-logo-white.png"
            media="(prefers-color-scheme: dark)"
          ><img src="/sponsors/tb-logo-black.png">
          </picture>
        </a>
        <a href="https://shiguredo.jp" rel="noopener nofollow" target="_blank">
          <picture>
            <source
            srcset="/sponsors/shiguredo-logo-dark.svg"
            media="(prefers-color-scheme: dark)"
          ><img src="/sponsors/shiguredo-logo-light.svg