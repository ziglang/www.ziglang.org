---
.title = "Pagina Principale",
.author = "",
.date = @date("2024-08-07:00:00:00"),
.layout = "index.shtml",
.custom = {
	"mobile_menu_title": "Home",
},
---

# [Slogan]($block.id("slogan"))
Zig e' un linguaggio di programmazione general purpose...

# [Features]($block.id("features"))

## ⚡ Un linguaggio semplice

## ⚡ Comptime

## ⚡ Mantieni i tuoi progetti con Zig

# [La community e' decentralizzata]($block.id("decentralized")) 

# [Community]($block.id("community"))
## [Main development]($block.id("main-development"))
## [Zig Software Foundation]($block.id("zsf").attrs("section-title"))

## The ZSF is a 501(c)(3) non-profit corporation.

# [Sponsors]($block.id('sponsors').attrs('section-title'))
## [Corporate Sponsors]($block.id("corporate-sponsors")) 

## [GitHub Sponsors]($block.id("github-sponsors"))

