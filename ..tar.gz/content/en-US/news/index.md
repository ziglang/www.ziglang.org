---
.title = "News",
.author = "",
.date = @date("2024-08-07:00:00:00"),
.layout = "news.shtml",
.custom = {
	"mobile_menu_title": "News",
},
---
News page
